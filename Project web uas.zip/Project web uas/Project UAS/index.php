    <!DOCTYPE html>
    <html lang="id">
    <head>
        <meta charset="UTF-8">
        <title>KOST BIRU - Home</title>
        <link rel="stylesheet" type="text/css" href="css/style.css">
    </head>
    <body>
        <header>
            <h1>KOST BIRU</h1>
            <nav>
                <a href="index.php">Home</a>
                <a href="katalog.php">Katalog</a>
                <a href="kontak.php">Kontak</a>
                <a href="admin_booking.php" style="border-left: 1px solid #ccc; padding-left: 15px; color: #3498db;">Admin</a>
            </nav>
        </header>

        <div class="container">
            <h2 class="fade-text">Selamat Datang di Hunian Nyaman</h2>
            <p>Temukan kamar impianmu dengan fasilitas lengkap dan desain aesthetic,Kost Biru hadir sebagai solusi hunian bagi mahasiswa maupun karyawan yang mendambakan suasana tenang dan bersih. Setiap unit kamar kami dirawat secara berkala untuk memastikan kenyamanan Anda selama tinggal bersama kami.</p>
            
            <img src="img/kosbiru.png" class="main-img" alt="Foto Kost Biru">
            
            <div style="margin-top: 20px;">
                <a href="katalog.php" class="btn-pink">Lihat Katalog Kamar</a>
            </div>
        </div>
    </body>
    </html>