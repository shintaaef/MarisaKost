<?php
session_start();
if (!isset($_SESSION['admin_login'])) {
    header("Location: login.php");
    exit();
}

include "koneksi.php"; 
if (!isset($kon)) {
    die("Error: Variabel koneksi \$kon tidak ditemukan. Periksa file koneksi.php");
}

$query = mysqli_query($kon, "SELECT * FROM booking ORDER BY id DESC"); 
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Admin - Kost Biru</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        .container-admin { 
            width: 95%; 
            max-width: 1200px; 
            margin: 30px auto; 
            background: white; 
            padding: 25px; 
            border-radius: 12px; 
            box-shadow: 0 4px 15px rgba(0,0,0,0.1); 
        }
        
        table { width: 100%; border-collapse: collapse !important; margin-top: 20px; border: 1px solid #ddd; }
        
        th { background-color: #34495e; color: white; padding: 15px; border: 1px solid #ddd !important; text-transform: uppercase; font-size: 14px; }
        
        td { padding: 12px; border: 1px solid #ddd !important; text-align: center; font-size: 14px; color: #333; }
        
        tr:nth-child(even) { background-color: #f9f9f9; }
        
        .btn-tambah { 
            background-color: #27ae60; 
            color: white; 
            padding: 10px 20px; 
            text-decoration: none; 
            border-radius: 6px; 
            display: inline-block; 
            font-weight: bold; 
            transition: 0.3s; 
        }
        .btn-tambah:hover { background-color: #219150; transform: translateY(-2px); }

        .nav-admin { margin: 20px 0; text-align: center; }
        .nav-admin a { margin: 0 15px; text-decoration: none; color: #3498db; font-weight: bold; font-size: 14px; }
        .nav-admin a:hover { text-decoration: underline; }
        
        .user-info {
            text-align: center;
            font-size: 12px;
            color: #7f8c8d;
            margin-bottom: 10px;
        }
    </style>
</head>
<body>

    <h2 style="text-align: center; color: #2c3e50; margin-top: 30px;">DATA PENYEWA KOST BIRU</h2>
    
    <div class="user-info">
        Login sebagai: <strong><?php echo $_SESSION['admin_login']; ?></strong>
    </div>

    <div class="nav-admin">
        <a href="index.php">LIHAT WEBSITE</a>
        <a href="admin_booking.php" style="border-bottom: 2px solid #3498db;">KELOLA BOOKING</a>
        <a href="katalog.php">DATA KAMAR</a>
        <a href="logout.php" style="color:#e74c3c;">LOGOUT</a>
    </div>

    <div class="container-admin">
        <div style="text-align: right; margin-bottom: 15px;">
            <a href="katalog.php" class="btn-tambah">+ TAMBAH BOOKING BARU</a>
        </div>

        <table>
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama Penyewa</th>
                    <th>WhatsApp</th>
                    <th>Tipe Kamar</th>
                    <th>Tgl Masuk</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $no = 1;
                if($query && mysqli_num_rows($query) > 0) {
                    while($data = mysqli_fetch_array($query)) { 
                ?>
                <tr>
                    <td><?php echo $no++; ?></td>
                    <td><strong><?php echo htmlspecialchars($data['nama_lengkap']); ?></strong></td>
                    <td><?php echo htmlspecialchars($data['whatsapp']); ?></td>
                    <td>
                        <span style="background: #ebf5fb; padding: 4px 8px; border-radius: 4px; color: #2980b9; font-size: 12px; font-weight: bold;">
                            <?php echo htmlspecialchars($data['tipe_kamar']); ?>
                        </span>
                    </td>
                    <td><?php echo date('d M Y', strtotime($data['tanggal_masuk'])); ?></td>
                    <td>
                        <a href="edit_booking.php?id=<?php echo $data['id']; ?>" style="color: #f1c40f; text-decoration: none; font-weight: bold;">Edit</a> | 
                        <a href="hapus_booking.php?id=<?php echo $data['id']; ?>" style="color: #e74c3c; text-decoration: none; font-weight: bold;" onclick="return confirm('Apakah Anda yakin ingin menghapus data penyewa ini?')">Hapus</a>
                    </td>
                </tr>
                <?php 
                    }
                } else {
                    echo "<tr><td colspan='6' style='padding: 30px; color: #999;'>Belum ada data penyewa yang terdaftar.</td></tr>";
                }
                ?>
            </tbody>
        </table>
    </div>

</body>
</html>