<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kontak Kami - KOST BIRU</title>
    <link rel="stylesheet" type="text/css" href="css/style.css">
</head>
<body>
    <header>
        <h1>Hubungi Kami !</h1>
       <nav>
    <a href="index.php">Home</a>
    <a href="katalog.php">Katalog</a>
    <a href="kontak.php">Kontak</a>
    <a href="admin_booking.php" style="border-left: 1px solid #ccc; padding-left: 15px; color: #3498db;">Admin</a>
</nav>
    </header>

    <div class="container">
        <h2>Ada Pertanyaan?</h2>
        <p>Kami siap membantu Anda menemukan hunian terbaik dan cocok untuk anak kuliah maupun yang bekerja.Silahkan hubungi kami melalui saluran di bawah ini:</p>
        
        <div style="margin-top: 30px; text-align: left; display: inline-block;">
            <p><strong>📍 Lokasi:</strong> Jl.bangau,Palembang</p>
            <p><strong>📞 WhatsApp:</strong> 0857-3456-7890</p>
            <p><strong>📧 Email:</strong> hello@kostbiru.com</p>
            <p><strong>⏰ Jam Operasional:</strong> 08.00 - 10.00 WIB</p>
        </div>

        <hr style="border: 0; border-top: 2px solid #ffdae9; margin: 30px 0;">

        <h3>Kirim Pesan Cepat</h3>
        <form style="text-align: left; display: inline-block; width: 100%; max-width: 400px;">
            <label>Nama Anda:</label><br>
            <input type="text" placeholder="Masukkan nama..." style="width: 100%; padding: 10px; margin: 10px 0; border: 1px solid #ffdae9; border-radius: 10px;"><br>
            
            <label>Pesan:</label><br>
            <textarea rows="4" placeholder="Tulis pesan Anda di sini..." style="width: 100%; padding: 10px; margin: 10px 0; border: 1px solid #ffdae9; border-radius: 10px; font-family: inherit;"></textarea><br>
            
            <button type="button" class="btn-pink" style="width: 100%; cursor: pointer;" onclick="alert('Pesan Anda telah terkirim!')">Kirim ke WhatsApp</button>
        </form>
    </div>

    <footer style="text-align: center; color: #2980b9; padding-bottom: 20px;">
        <p>&copy; 2026 KOST BIRU BANGAU</p>
    </footer>
</body>
</html>