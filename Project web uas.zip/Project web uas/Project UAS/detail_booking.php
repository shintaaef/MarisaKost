<?php
include "koneksi.php";

$tipe = isset($_GET['tipe']) ? $_GET['tipe'] : '';

if ($tipe == "AC-Dalam") {
    $gambar_utama = "img/kmdalam.jpg";
    $nama_kamar   = "AC + KM Dalam";
    $harga        = "Rp 1.800.000 / bln";
} elseif ($tipe == "AC-Luar") {
    $gambar_utama = "img/kamarac.jfif"; 
    $nama_kamar   = "AC + KM Luar";
    $harga        = "Rp 1.500.000 / bln";
} elseif ($tipe == "Kipas-Dalam") {
    $gambar_utama = "img/kamarkipas.jfif";
    $nama_kamar   = "Kipas + KM Dalam";
    $harga        = "Rp 800.000 / bln";
} else {
    header("Location: katalog.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Booking - <?php echo $nama_kamar; ?></title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>

    <header>
        <h1>KOST BIRU</h1>
        <nav>
            <a href="index.php">Home</a>
            <a href="katalog.php">Katalog</a>
            <a href="kontak.php">Kontak</a>
            <a href="admin_booking.php" style="border-left: 1px solid rgba(255,255,255,0.3); margin-left: 15px;">Admin</a>
        </nav>
    </header>

    <div class="container">
        <h2>Detail Kamar</h2>
        
        <div class="split-container">
            <div class="side-img">
                <img src="<?php echo $gambar_utama; ?>" alt="<?php echo $nama_kamar; ?>">
                <h3><?php echo $nama_kamar; ?></h3>
                <p style="color: #2980b9; font-weight: bold; font-size: 1.2rem;"><?php echo $harga; ?></p>
                <p>Silakan isi form di samping untuk melakukan pemesanan unit ini.</p>
            </div>

            <div class="side-form">
                <h3 style="color: #3498db; margin-top: 0;">Form Pemesanan</h3>
                <form action="proses_booking.php" method="POST">
                    <input type="hidden" name="tipe_kamar" value="<?php echo $nama_kamar; ?>">
                    
                    <label>Nama Lengkap</label>
                    <input type="text" name="nama_lengkap" placeholder="Nama sesuai KTP" required>
                    
                    <label>Nomor WhatsApp</label>
                    <input type="text" name="whatsapp" placeholder="Contoh: 08123456789" required>
                    
                    <label>Tanggal Rencana Masuk</label>
                    <input type="date" name="tanggal_masuk" required>
                    
                    <button type="submit" class="btn-pink">KONFIRMASI PESANAN</button>
                    
                    <div style="text-align: center; margin-top: 15px;">
                        <a href="katalog.php" style="color: #3498db; text-decoration: none; font-size: 0.9rem;">← Kembali ke Katalog</a>
                    </div>
                </form>
            </div>
        </div> </div> </body>
</html>