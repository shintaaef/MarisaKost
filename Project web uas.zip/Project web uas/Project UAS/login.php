<?php
session_start();
include "koneksi.php";

if (isset($_POST['login'])) {
    $user = $_POST['username'];
    $pass = $_POST['password'];

    $query = mysqli_query($kon, "SELECT * FROM users WHERE username='$user' AND password='$pass'");

    if ($query && mysqli_num_rows($query) > 0) {
        $_SESSION['admin_login'] = $user;
        echo "<script>alert('Login Berhasil!'); window.location.href='admin_booking.php';</script>";
        exit();
    } else {
        echo "<script>alert('Login Gagal! Username atau Password Salah'); window.location.href='login.php';</script>";
        exit();
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Login Admin</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container" style="max-width: 400px; margin-top: 100px;">
        <h2>Login Admin</h2>
        <form method="POST">
            <label>Username</label>
            <input type="text" name="username" required>
            <label>Password</label>
            <input type="password" name="password" required>
            <button type="submit" name="login" class="btn-pink">LOGIN</button>
        </form>
    </div>
</body>
</html>