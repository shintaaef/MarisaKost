<?php
include "koneksi.php";

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $delete = mysqli_query($kon, "DELETE FROM booking WHERE id = '$id'");

    if ($delete) {
        echo "<script>
                alert('Data penyewa berhasil dihapus.');
                window.location.href = 'admin_booking.php';
              </script>";
    } else {
        echo "Gagal menghapus data: " . mysqli_error($kon);
    }
}    else {
    header("Location: admin_booking.php");
}
?>