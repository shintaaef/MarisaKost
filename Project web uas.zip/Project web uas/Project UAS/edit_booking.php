<?php
include "koneksi.php";

if (!isset($kon)) {
    die("Error: Koneksi database tidak ditemukan.");
}

$id = $_GET['id'];
$query = mysqli_query($kon, "SELECT * FROM booking WHERE id = '$id'");
$data = mysqli_fetch_array($query);

if (!$data) {
    die("Data tidak ditemukan.");
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Edit Pemesanan - Admin</title>
    <link rel="stylesheet" href="css/style.css">
    
    <style>
        .container-admin {
            max-width: 500px;
            margin: 50px auto;
            background: #ffffff;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 10px 25px rgba(0,0,0,0.1);
            font-family: 'Segoe UI', sans-serif;
        }

        h2 { color: #2c3e50; margin-bottom: 20px; }

        label { font-weight: bold; color: #34495e; display: block; margin-top: 10px; }

        input {
            width: 100%;
            padding: 12px;
            margin: 8px 0 20px 0;
            border: 1px solid #d1e9ff;
            border-radius: 8px;
            box-sizing: border-box;
            transition: 0.3s;
        }

        input:focus { border-color: #3498db; outline: none; box-shadow: 0 0 8px rgba(52,152,219,0.2); }

        /* Gaya Tombol Modern */
        .button-group { display: flex; gap: 10px; margin-top: 20px; }

        .btn-save {
            flex: 2;
            background: linear-gradient(135deg, #3498db, #2980b9);
            color: white;
            border: none;
            padding: 14px;
            border-radius: 8px;
            font-weight: bold;
            cursor: pointer;
            transition: 0.3s;
            text-transform: uppercase;
        }

        .btn-save:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(52, 152, 219, 0.3);
        }

        .btn-cancel {
            flex: 1;
            background: #ecf0f1;
            color: #7f8c8d;
            text-decoration: none;
            padding: 14px;
            border-radius: 8px;
            text-align: center;
            font-weight: bold;
            transition: 0.3s;
        }

        .btn-cancel:hover { background: #bdc3c7; color: #2c3e50; }
    </style>
</head>
<body>

    <div class="container-admin">
        <h2 style="text-align: center;">Edit Data Pemesanan</h2>
        <hr style="border: 0; border-top: 1px solid #eee; margin-bottom: 25px;">
        
        <form action="update_booking.php" method="POST">
            <input type="hidden" name="id" value="<?php echo $data['id']; ?>">

            <label>Nama Lengkap</label>
            <input type="text" name="nama_lengkap" value="<?php echo htmlspecialchars($data['nama_lengkap']); ?>" required>

            <label>Nomor WhatsApp</label>
            <input type="text" name="whatsapp" value="<?php echo htmlspecialchars($data['whatsapp']); ?>" required>

            <label>Tipe Kamar</label>
            <input type="text" name="tipe_kamar" value="<?php echo htmlspecialchars($data['tipe_kamar']); ?>" readonly style="background: #f8f9fa; color: #7f8c8d;">

            <label>Tanggal Rencana Masuk</label>
            <input type="date" name="tanggal_masuk" value="<?php echo $data['tanggal_masuk']; ?>" required>

            <div class="button-group">
                <button type="submit" class="btn-save">SIMPAN PERUBAHAN</button>
                <a href="admin_booking.php" class="btn-cancel">BATAL</a>
            </div>
        </form>
    </div>

</body>
</html>