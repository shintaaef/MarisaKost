<?php
include "koneksi.php";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id = $_POST['id'];
    $nama = $_POST['nama_lengkap'];
    $wa = $_POST['whatsapp'];
    $tgl = $_POST['tanggal_masuk'];
    $update = mysqli_query($kon, "UPDATE booking SET 
                nama_lengkap = '$nama', 
                whatsapp = '$wa', 
                tanggal_masuk = '$tgl', 
                WHERE id = '$id'");

    if ($update) {
        echo "<script>alert('Data berhasil diupdate!'); window.location='admin_booking.php';</script>";
    } else {
        echo "Gagal update: " . mysqli_error($kon);
    }
}
?>