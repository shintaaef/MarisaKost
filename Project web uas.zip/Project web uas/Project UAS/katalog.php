<?php include "koneksi.php"; ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Katalog Kamar - Kost Biru</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header>
        <h1>KOST BIRU</h1>
        <nav>
       <a href="index.php">Home</a>
        <a href="katalog.php">Katalog</a>
        <a href="kontak.php">Kontak</a>
        <a href="admin_booking.php" style="border-left: 1px solid #ccc; padding-left: 15px; color: #3498db;">Admin</a>
            </nav>
        </nav>
    </header>

    <div class="container">
        <h2 style="margin-top: 20px;">Katalog Kamar Minimalis</h2>
        <p>Pilih tipe kamar yang Anda inginkan:</p>

        <div class="card-container">
            <div class="card">
                <img src="img/kmdalam.jpg" alt="Kamar AC">
                <div style="padding: 15px;">
                    <h3>AC + KM Dalam</h3>
                    <p>Rp 1.500.000 / bln</p>
                    <a href="detail_booking.php?tipe=AC-Dalam" class="btn-pink">Booking Sekarang</a>
                </div>
            </div>

            <div class="card">
                <img src="img/kmrkos.jfif" alt="Kamar Kipas"> <div style="padding: 15px;">
                    <h3>Kipas + KM Luar</h3>
                    <p>Rp 800.000 / bln</p>
                    <a href="detail_booking.php?tipe=Kipas-Luar" class="btn-pink">Booking Sekarang</a>
                </div>
            </div>

            <div class="card">
                <img src="img/kamarac.jfif" alt="Kamar Eksklusif">
                <div style="padding: 15px;">
                    <h3>AC + KM Luar</h3>
                    <p>Rp 1.200.000 / bln</p>
                    <a href="detail_booking.php?tipe=AC-Luar" class="btn-pink">Booking Sekarang</a>
                </div>
            </div>
        </div> </div> </body>
</html>