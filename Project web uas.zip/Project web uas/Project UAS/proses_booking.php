<?php
include "koneksi.php";

$nama = $_POST['nama_lengkap'];
$wa = $_POST['whatsapp'];
$tipe = $_POST['tipe_kamar'];
$tgl = $_POST['tanggal_masuk'];

$query = mysqli_query($kon, "INSERT INTO booking (nama_lengkap, whatsapp, tipe_kamar, tanggal_masuk) 
                             VALUES ('$nama', '$wa', '$tipe', '$tgl')");

if ($query) {
    echo "<script>alert('Berhasil Booking!'); window.location='admin_booking.php';</script>";
} else {
    // Ini untuk melihat error jika query gagal
    echo "Gagal: " . mysqli_error($kon); 
}
?>